from fastapi.testclient import TestClient
from app import routes
from app.main import app
from app.schemas import CrackReport

client = TestClient(app)
PNG = b"\x89PNG\r\n\x1a\n" + b"0" * 32


def fake_llm(system, context, schema, image=None, media_type=None):
    return CrackReport(summary="Hairline cracks.", structural_risk="low", findings=[],
                       recommended_actions=["Monitor monthly."], needs_engineer_inspection=False, confidence=0.7)


def test_crack_requires_image():
    assert client.post("/api/cracks", data={"payload": "{}"}).status_code == 422


def test_crack_returns_contract(monkeypatch):
    monkeypatch.setattr(routes, "run_llm", fake_llm)
    r = client.post("/api/cracks", data={"payload": "{}"}, files={"image": ("w.png", PNG, "image/png")})
    assert r.status_code == 200
    assert set(r.json()) == set(CrackReport.model_fields)


def test_invalid_payload_and_unknown_module():
    assert client.post("/api/valuation", data={"payload": '{"location": "x"}'}).status_code == 422
    assert client.post("/api/nope", data={"payload": "{}"}).status_code == 404
