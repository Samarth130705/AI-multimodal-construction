// Every module uses the same contract: multipart form with a JSON `payload` and an optional `image`.
export async function runModule(key, payload, image) {
  const body = new FormData();
  body.append("payload", JSON.stringify(payload));
  if (image) body.append("image", image);

  const res = await fetch(`/api/${key}`, { method: "POST", body });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const d = data.detail;
    const message = Array.isArray(d)
      ? d.map((e) => `${e.loc?.slice(-1)[0] ?? "input"}: ${e.msg}`).join("; ")
      : typeof d === "string" ? d : `Request failed (${res.status}). Check the inputs and try again.`;
    throw new Error(message);
  }
  return data;
}
