import { useMemo, useState } from "react";
import { runModule } from "./api.js";

const select = (name, label, options) => ({ name, label, type: "select", options });

const MODULES = [
  { key: "safety", label: "Site safety", image: "required",
    blurb: "Upload a site photo. Get visible PPE, fall-protection, housekeeping and equipment issues with fixes.",
    fields: [{ name: "notes", label: "Site notes", type: "textarea", placeholder: "e.g. slab casting on level 3" }] },
  { key: "cracks", label: "Crack analysis", image: "required",
    blurb: "Upload a photo of a crack. Get the pattern, likely cause, risk level and next steps.",
    fields: [
      { name: "element", label: "Structural element", type: "text", placeholder: "e.g. load-bearing wall, column, slab soffit" },
      { name: "notes", label: "Notes", type: "textarea", placeholder: "When did it appear? Has it grown?" }] },
  { key: "valuation", label: "Property valuation", image: "optional",
    blurb: "Enter property details for an indicative market value and range.",
    fields: [
      { name: "location", label: "Location", type: "text", required: true, placeholder: "Locality, city" },
      select("property_type", "Property type", ["apartment", "independent house", "villa", "plot", "commercial"]),
      { name: "area_sqft", label: "Area (sq ft)", type: "number", required: true },
      { name: "age_years", label: "Age (years)", type: "number" },
      { name: "bedrooms", label: "Bedrooms", type: "number" },
      select("condition", "Condition", ["new", "good", "average", "needs repair"]),
      { name: "amenities", label: "Amenities", type: "list", placeholder: "Comma separated: lift, parking, garden" },
      select("currency", "Currency", ["INR", "USD", "EUR", "GBP", "AED"])] },
  { key: "planning", label: "Project plan",
    blurb: "Describe the project. Get phases, durations, crew, cost split and risks.",
    fields: [
      { name: "project_name", label: "Project name", type: "text", required: true },
      select("project_type", "Project type", ["residential building", "commercial building", "road", "bridge", "warehouse", "renovation"]),
      { name: "location", label: "Location", type: "text" },
      { name: "built_up_area_sqft", label: "Built-up area (sq ft)", type: "number" },
      { name: "floors", label: "Floors", type: "number" },
      { name: "budget", label: "Budget", type: "number" },
      { name: "duration_months", label: "Target duration (months)", type: "number" },
      { name: "notes", label: "Constraints", type: "textarea" }] },
  { key: "assistant", label: "Daily assistant", image: "optional",
    blurb: "Ask about today's work. Attach a photo if it helps.",
    fields: [
      { name: "message", label: "Question", type: "textarea", required: true, placeholder: "e.g. Rebar for the beam is delayed. What can the crew do today?" },
      { name: "site_context", label: "Site context", type: "textarea", placeholder: "Stage of work, crew size, equipment on site" }] },
  { key: "weather", label: "Weather advisory", geo: true,
    blurb: "Check the 5-day forecast against your planned activities.",
    fields: [
      { name: "latitude", label: "Latitude", type: "number", required: true },
      { name: "longitude", label: "Longitude", type: "number", required: true },
      { name: "planned_activities", label: "Planned activities", type: "textarea", required: true, placeholder: "Concrete pour on Thursday, crane lift on Friday" }] },
  { key: "knowledge", label: "Knowledge base",
    blurb: "Ask a materials, methods or code question at the depth you need.",
    fields: [
      { name: "question", label: "Question", type: "textarea", required: true, placeholder: "e.g. What is the minimum curing period for OPC concrete?" },
      select("level", "Depth", ["beginner", "practitioner", "expert"])] },
];

function buildPayload(fields, values) {
  const out = {};
  for (const f of fields) {
    const v = values[f.name];
    if (v === undefined || v === "") continue;
    out[f.name] = f.type === "number" ? Number(v)
      : f.type === "list" ? v.split(",").map((x) => x.trim()).filter(Boolean) : v;
  }
  return out;
}

/* ---------- Result rendering: works for any contract ---------- */
const TAG = { low: "ok", medium: "warn", high: "bad", critical: "bad",
  proceed: "ok", proceed_with_caution: "warn", postpone: "bad" };
const label = (k) => k.replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase());

function Value({ k, v }) {
  if (v === null || v === undefined) return <span className="muted">Not available</span>;
  if (typeof v === "boolean") return <span className={`tag ${v ? "bad" : "ok"}`}>{v ? "Yes" : "No"}</span>;
  if (typeof v === "number")
    return <span>{k.includes("confidence") ? `${Math.round(v * 100)}%` : v.toLocaleString("en-IN")}</span>;
  if (typeof v === "string")
    return TAG[v] ? <span className={`tag ${TAG[v]}`}>{label(v)}</span> : <span>{v}</span>;
  if (Array.isArray(v))
    return v.length === 0 ? <span className="muted">None</span> : (
      <ul className="list">{v.map((x, i) => (
        <li key={i}>{typeof x === "object" ? <Record data={x} /> : <Value k={k} v={x} />}</li>))}</ul>);
  return <Record data={v} />;
}

function Record({ data }) {
  return (
    <dl className="rec">
      {Object.entries(data).map(([k, v]) => (
        <div key={k}><dt>{label(k)}</dt><dd><Value k={k} v={v} /></dd></div>))}
    </dl>
  );
}

function Result({ data }) {
  const { summary, answer, ...rest } = data;
  return (
    <div className="result">
      <p className="lead">{summary ?? answer}</p>
      <Record data={rest} />
      <details><summary>Raw JSON</summary><pre>{JSON.stringify(data, null, 2)}</pre></details>
    </div>
  );
}

/* ---------- One generic panel drives every module ---------- */
function Panel({ mod }) {
  const [values, setValues] = useState({});
  const [image, setImage] = useState(null);
  const [state, setState] = useState({ status: "idle" });
  const preview = useMemo(() => (image ? URL.createObjectURL(image) : null), [image]);
  const set = (name, v) => setValues((s) => ({ ...s, [name]: v }));

  async function submit(e) {
    e.preventDefault();
    setState({ status: "loading" });
    try {
      setState({ status: "done", data: await runModule(mod.key, buildPayload(mod.fields, values), image) });
    } catch (err) {
      setState({ status: "error", message: err.message });
    }
  }

  function locate() {
    navigator.geolocation.getCurrentPosition(
      (p) => { set("latitude", p.coords.latitude.toFixed(4)); set("longitude", p.coords.longitude.toFixed(4)); },
      () => setState({ status: "error", message: "Location permission was denied. Enter the coordinates by hand." }));
  }

  return (
    <div className="panel">
      <form onSubmit={submit} className="input">
        <h2>{mod.label}</h2>
        <p className="blurb">{mod.blurb}</p>

        {mod.image && (
          <label className="drop">
            {preview ? <img src={preview} alt="Selected upload" /> :
              <span>{mod.image === "required" ? "Choose a photo (required)" : "Choose a photo (optional)"}</span>}
            <input type="file" accept="image/*" required={mod.image === "required"}
              onChange={(e) => setImage(e.target.files[0] ?? null)} />
          </label>
        )}

        {mod.fields.map((f) => (
          <label key={f.name} className="field">
            <span>{f.label}</span>
            {f.type === "select" ? (
              <select value={values[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)}>
                <option value="">Select</option>
                {f.options.map((o) => <option key={o}>{o}</option>)}
              </select>
            ) : f.type === "textarea" ? (
              <textarea rows={3} required={f.required} placeholder={f.placeholder}
                value={values[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} />
            ) : (
              <input type={f.type === "number" ? "number" : "text"} step="any" required={f.required}
                placeholder={f.placeholder} value={values[f.name] ?? ""}
                onChange={(e) => set(f.name, e.target.value)} />
            )}
          </label>
        ))}

        {mod.geo && <button type="button" className="ghost" onClick={locate}>Use my current location</button>}
        <button className="primary" disabled={state.status === "loading"}>
          {state.status === "loading" ? "Analysing…" : "Run analysis"}
        </button>
      </form>

      <section className="output" aria-live="polite">
        {state.status === "idle" && <p className="muted">Results appear here.</p>}
        {state.status === "loading" && <p className="muted">Working on it. This usually takes 10 to 30 seconds.</p>}
        {state.status === "error" && <p className="error">{state.message}</p>}
        {state.status === "done" && <Result data={state.data} />}
      </section>
    </div>
  );
}

export default function App() {
  const [active, setActive] = useState(MODULES[0].key);
  const mod = MODULES.find((m) => m.key === active);
  return (
    <div className="shell">
      <header>
        <h1>Construction Intelligence</h1>
        <div className="hazard" aria-hidden="true" />
      </header>
      <nav aria-label="Modules">
        {MODULES.map((m) => (
          <button key={m.key} className={m.key === active ? "on" : ""} onClick={() => setActive(m.key)}>{m.label}</button>))}
      </nav>
      <main><Panel key={mod.key} mod={mod} /></main>
    </div>
  );
}
