"""Strict JSON contracts. Every AI response is validated against these models
before it reaches the frontend, so the UI never sees malformed output."""
from typing import Literal, Optional
from pydantic import BaseModel, Field

Severity = Literal["low", "medium", "high", "critical"]
Confidence = Field(ge=0, le=1, description="0 to 1, how sure the model is given the input quality")


# ---------- Safety monitoring ----------
class SafetyRequest(BaseModel):
    notes: Optional[str] = None

class SafetyViolation(BaseModel):
    category: Literal["ppe", "fall_protection", "housekeeping", "equipment", "electrical", "excavation", "other"]
    description: str
    severity: Severity
    corrective_action: str

class SafetyReport(BaseModel):
    summary: str
    safety_score: int = Field(ge=0, le=100)
    violations: list[SafetyViolation]
    positive_observations: list[str]
    confidence: float = Confidence


# ---------- Crack detection ----------
class CrackRequest(BaseModel):
    element: Optional[str] = None
    notes: Optional[str] = None

class CrackFinding(BaseModel):
    location: str
    pattern: Literal["hairline", "vertical", "horizontal", "diagonal", "stair_step", "map_cracking", "other"]
    estimated_width_mm: Optional[float] = None
    likely_cause: str
    severity: Severity

class CrackReport(BaseModel):
    summary: str
    structural_risk: Severity
    findings: list[CrackFinding]
    recommended_actions: list[str]
    needs_engineer_inspection: bool
    confidence: float = Confidence


# ---------- Real estate valuation ----------
class ValuationRequest(BaseModel):
    location: str
    property_type: str
    area_sqft: float = Field(gt=0)
    age_years: int = Field(default=0, ge=0)
    bedrooms: Optional[int] = None
    condition: Optional[str] = None
    amenities: list[str] = []
    currency: str = "INR"

class ValueRange(BaseModel):
    low: int
    high: int

class ValuationReport(BaseModel):
    summary: str
    currency: str
    estimated_value: int
    value_range: ValueRange
    price_per_sqft: int
    key_factors: list[str]
    assumptions: list[str]
    confidence: float = Confidence


# ---------- Project planning ----------
class PlanRequest(BaseModel):
    project_name: str
    project_type: str
    location: Optional[str] = None
    built_up_area_sqft: Optional[float] = None
    floors: int = Field(default=1, ge=1)
    budget: Optional[float] = None
    duration_months: Optional[int] = None
    notes: Optional[str] = None

class Phase(BaseModel):
    name: str
    duration_weeks: int
    tasks: list[str]
    depends_on: list[str]

class Resource(BaseModel):
    role: str
    count: int

class CostShare(BaseModel):
    item: str
    share_percent: float

class Risk(BaseModel):
    risk: str
    severity: Severity
    mitigation: str

class ProjectPlan(BaseModel):
    summary: str
    total_duration_weeks: int
    phases: list[Phase]
    resources: list[Resource]
    cost_breakdown: list[CostShare]
    risks: list[Risk]
    confidence: float = Confidence


# ---------- Daily site assistant ----------
class AssistantRequest(BaseModel):
    message: str
    site_context: Optional[str] = None

class AssistantReply(BaseModel):
    answer: str
    action_items: list[str]
    follow_up_questions: list[str]


# ---------- Weather advisory ----------
class WeatherRequest(BaseModel):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    planned_activities: str

class ActivityAdvice(BaseModel):
    activity: str
    recommendation: Literal["proceed", "proceed_with_caution", "postpone"]
    reason: str

class WeatherAdvisory(BaseModel):
    summary: str
    overall_risk: Severity
    activity_advice: list[ActivityAdvice]
    precautions: list[str]


# ---------- Knowledge assistant ----------
class KnowledgeRequest(BaseModel):
    question: str
    level: Literal["beginner", "practitioner", "expert"] = "practitioner"

class KnowledgeAnswer(BaseModel):
    answer: str
    key_points: list[str]
    relevant_standards: list[str]
    caveats: list[str]
