import json
from typing import Optional
from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import ValidationError
from .llm import run_llm
from .modules import MODULES

router = APIRouter()
ALLOWED_IMAGES = {"image/jpeg", "image/png", "image/webp", "image/gif"}
MAX_IMAGE_BYTES = 5 * 1024 * 1024


@router.get("/health")
def health():
    return {"status": "ok", "modules": list(MODULES)}


@router.get("/contracts/{module}")
def contract(module: str):
    """Publishes the request/response JSON Schemas so the frontend (or tests) can rely on them."""
    spec = MODULES.get(module)
    if not spec:
        raise HTTPException(404, f"Unknown module '{module}'.")
    return {"request": spec.request.model_json_schema(), "response": spec.response.model_json_schema(),
            "image": spec.image}


@router.post("/{module}")
def run_module(module: str, payload: str = Form("{}"), image: Optional[UploadFile] = File(None)):
    spec = MODULES.get(module)
    if not spec:
        raise HTTPException(404, f"Unknown module '{module}'.")
    try:
        req = spec.request.model_validate_json(payload)
    except ValidationError as e:
        raise HTTPException(422, json.loads(e.json()))

    data, media_type = None, None
    if image and image.filename and spec.image != "none":
        if image.content_type not in ALLOWED_IMAGES:
            raise HTTPException(422, "Upload a JPEG, PNG, WebP or GIF image.")
        data = image.file.read()
        if len(data) > MAX_IMAGE_BYTES:
            raise HTTPException(422, "Image is larger than 5 MB. Upload a smaller file.")
        media_type = image.content_type
    if spec.image == "required" and not data:
        raise HTTPException(422, "This analysis needs a photo. Upload one and try again.")

    context = req.model_dump(exclude_none=True)
    if spec.enrich:
        context["live_data"] = spec.enrich(req)
    return run_llm(spec.system, context, spec.response, data, media_type).model_dump()
