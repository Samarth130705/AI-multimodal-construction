"""Streamlit front end for the platform.

It imports the same module registry and JSON contracts as the FastAPI app, so no separate
API server is needed. Forms are generated from the request models in app/schemas.py.
Run from this folder:  streamlit run streamlit_app.py
"""
import os
from typing import Literal, get_args, get_origin

import streamlit as st

# Expose Streamlit secrets as env vars BEFORE importing app.llm (it reads them on import).
for _k in ("ANTHROPIC_API_KEY", "LLM_MODEL"):
    try:
        if _k in st.secrets:
            os.environ[_k] = str(st.secrets[_k])
    except Exception:
        pass  # no secrets file: fall back to .env / environment

from fastapi import HTTPException
from pydantic import ValidationError

from app.llm import run_llm
from app.modules import MODULES

LABELS = {"safety": "Site safety", "cracks": "Crack analysis", "valuation": "Property valuation",
          "planning": "Project plan", "assistant": "Daily assistant", "weather": "Weather advisory",
          "knowledge": "Knowledge base"}
LONG_TEXT = {"notes", "message", "question", "planned_activities", "site_context"}
MAX_IMAGE_BYTES = 5 * 1024 * 1024

label = lambda name: name.replace("_", " ").capitalize()


def unwrap(ann):
    """Optional[X] -> X"""
    args = get_args(ann)
    if type(None) in args:
        return unwrap(next(a for a in args if a is not type(None)))
    return ann


def widget(module, name, field):
    """Pick a Streamlit input from a Pydantic field's type."""
    ann, key = unwrap(field.annotation), f"{module}_{name}"
    text = label(name) + (" *" if field.is_required() else "")
    if get_origin(ann) is Literal:
        options = list(get_args(ann))
        return st.selectbox(text, options, index=options.index(field.default) if field.default in options else 0, key=key)
    if get_origin(ann) is list:
        raw = st.text_input(text + " (comma separated)", key=key)
        return [x.strip() for x in raw.split(",") if x.strip()]
    if ann in (int, float):
        step = 0.01 if name in ("latitude", "longitude") else (1 if ann is int else 1.0)
        value = st.number_input(text, value=None, step=step, key=key)
        return None if value is None else ann(value)
    default = field.default if isinstance(field.default, str) else ""
    if name in LONG_TEXT:
        return st.text_area(text, value=default, key=key, height=100)
    return st.text_input(text, value=default, key=key)


def analyse(spec, payload, upload):
    try:
        req = spec.request.model_validate(payload)
    except ValidationError as e:
        raise ValueError("; ".join(f"{err['loc'][-1]}: {err['msg']}" for err in e.errors()))
    data = upload.getvalue() if upload and spec.image != "none" else None
    if spec.image == "required" and not data:
        raise ValueError("This analysis needs a photo. Upload one and try again.")
    if data and len(data) > MAX_IMAGE_BYTES:
        raise ValueError("Image is larger than 5 MB. Upload a smaller file.")
    context = req.model_dump(exclude_none=True)
    if spec.enrich:
        context["live_data"] = spec.enrich(req)
    return run_llm(spec.system, context, spec.response, data, upload.type if data else None).model_dump()


def fmt(key, v):
    if isinstance(v, bool):
        return "Yes" if v else "No"
    if isinstance(v, float) and "confidence" in key:
        return f"{round(v * 100)}%"
    if isinstance(v, (int, float)):
        return f"{v:,}"
    return str(v).replace("_", " ") if v is not None else "Not available"


def render(data):
    lead = data.get("summary") or data.get("answer")
    if lead:
        st.markdown(f"#### {lead}")
    for key, v in data.items():
        if key in ("summary", "answer"):
            continue
        if isinstance(v, list) and v and isinstance(v[0], dict):
            st.markdown(f"**{label(key)}**")
            st.dataframe(v, hide_index=True)
        elif isinstance(v, list) and v:
            st.markdown(f"**{label(key)}**\n" + "\n".join(f"- {x}" for x in v))
        elif isinstance(v, dict):
            st.markdown(f"**{label(key)}**")
            st.json(v)
        else:
            st.markdown(f"**{label(key)}:** {'None' if v == [] else fmt(key, v)}")
    with st.expander("Raw JSON"):
        st.json(data)


st.set_page_config(page_title="Construction Intelligence", layout="wide")
st.title("Construction Intelligence")
choice = st.sidebar.radio("Module", list(MODULES), format_func=LABELS.get)
spec = MODULES[choice]
st.header(LABELS[choice])

left, right = st.columns([1, 1.5], gap="large")
with left, st.form(choice):
    upload = None
    if spec.image != "none":
        upload = st.file_uploader("Photo" + (" *" if spec.image == "required" else " (optional)"),
                                  type=["jpg", "jpeg", "png", "webp"], key=f"{choice}_img")
    values = {name: widget(choice, name, f) for name, f in spec.request.model_fields.items()}
    submitted = st.form_submit_button("Run analysis", type="primary")

with right:
    if submitted:
        payload = {k: v for k, v in values.items() if v not in (None, "", [])}
        try:
            with st.spinner("Analysing. This usually takes 10 to 30 seconds."):
                result = analyse(spec, payload, upload)
            render(result)
        except ValueError as e:
            st.error(str(e))
        except HTTPException as e:
            st.error(str(e.detail))
    else:
        st.caption("Results appear here.")
